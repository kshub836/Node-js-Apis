// const categoryRouter = require("express").Router();
// const category = require("../controllers/categoryController");
// const auth = require ("../middleware/auth")

// var bodyParser = require('body-parser');
// categoryRouter.use(bodyParser.urlencoded({ extended: true }));
// categoryRouter.use(bodyParser.json());

// categoryRouter.post('/createCategaory',auth.verifyToken, category.createCategaory);


// module.exports = categoryRouter;