// const productRouter = require("express").Router();
// const product = require("../controllers/product");

// var bodyParser = require('body-parser');
// productRouter.use(bodyParser.urlencoded({ extended: true }));
// productRouter.use(bodyParser.json());

// productRouter.post('/productCreate', product.productCreate);
// productRouter.get('/productPopulate', product.productPopulate);

// module.exports = productRouter;